### Inter-Lidar ICP + Ground Plane Extraction (Sample)

**Purpose**: Align two LiDAR point clouds in real time using ICP, then extract and visualize the ground plane.

### Run
- From this directory or your workspace root, run the sample binary with the options below.
- Show help:

```bash
<lidar_icp> --help
```

### Required
- **--rigFile=FILE**: Path to rig configuration JSON (must define exactly 2 LiDARs and transforms).

### Common Options
- **--maxIters=N**: ICP iterations (default: 20)
- **--numFrames=N**: Frames to process (0 = unlimited; default: 0)
- **--skipFrames=N**: Initial frames to skip for sensor stabilization (default: 5)
- **--displayWindowWidth=N**: Window width (default: 1500)
- **--displayWindowHeight=N**: Window height (default: 900)
- **--verbose=true|false**: Verbose logging (default: false)
- **--savePointClouds=true|false**: Save point clouds as PLY (default: false)

### Example
```bash
<your_binary_name> \
  --rigFile=/usr/local/driveworks-5.20/samples/src/sensors/lidar/lidar_icp/rig.json \
  --maxIters=20 \
  --numFrames=0 \
  --skipFrames=5 \
  --displayWindowWidth=1500 \
  --displayWindowHeight=900 \
  --verbose=false \
  --savePointClouds=false
```

### Output
- 4-panel visualization: individual lidars, ICP alignment view, stitched result
- Console logs for ICP and ground plane detection
- Optional PLY files when enabled

### Create a tarball of this sample
- Create a compressed archive of the current sample directory:

```bash
tar -czf /tmp/lidar_icp_sample.tar.gz -C /usr/local/driveworks-5.20/samples/src/sensors/lidar/lidar_icp .
```

- Or archive only key source/config files:

```bash
tar -czf /tmp/lidar_icp_minimal.tar.gz \
    /usr/local/driveworks-5.20/samples/src/sensors/lidar/lidar_icp/main.cpp \
    /usr/local/driveworks-5.20/samples/src/sensors/lidar/lidar_icp/InterLidarICP.hpp \
    /usr/local/driveworks-5.20/samples/src/sensors/lidar/lidar_icp/rig.json
```

Replace `<your_binary_name>` with your built executable name.

